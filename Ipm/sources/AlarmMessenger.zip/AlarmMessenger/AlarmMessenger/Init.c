
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

#define false 0
#define true 1

void _INIT ProgramInit(void)
{
	GetLanguages.First = true;
	GetLanguages.Namespace = (UDINT) "IAT";
	for(int i = 0; i < MAX_LANGUAGES; i++)
	{
		GetLanguages.Execute = true;
		ArTextSysGetNamespaceLanguages(&GetLanguages);
		brsstrcpy((UDINT) languages[i], (UDINT) GetLanguages.LanguageCode);
		GetLanguages.Execute = false;
		GetLanguages.First = false;
		ArTextSysGetNamespaceLanguages(&GetLanguages);
		if (GetLanguages.EndOfList) break;
	}
	
	alarmHistMpLinks[0] = gAlarmHistForIPM_0;
	alarmHistMpLinks[1] = gAlarmHistForIPM_1;
	alarmHistMpLinks[2] = gAlarmHistForIPM_2;
	alarmHistMpLinks[3] = gAlarmHistForIPM_3;
	alarmHistMpLinks[4] = gAlarmHistForIPM_4;
	
	for (int i = 0; i < MAX_LANGUAGES; i++)
	{
		AlarmHistForIPM[i].Enable = true;
		AlarmHistForIPM[i].ErrorReset = GlobalAck;
		AlarmHistForIPM[i].MpLink = (UDINT) &alarmHistMpLinks[i];
		MpAlarmXHistory(&AlarmHistForIPM[i]);
	
		AlarmHistUIForIPM[i].Enable = true;
		AlarmHistUIForIPM[i].ErrorReset = GlobalAck;
		AlarmHistUIForIPM[i].MpLink = (UDINT) &alarmHistMpLinks[i];
		brsstrcpy((UDINT) AlarmHistUIForIPMConn[i].Language, (UDINT) languages[i]);
		AlarmHistUIForIPM[i].UIConnect = &AlarmHistUIForIPMConn[i];
		MpAlarmXHistoryUI(&AlarmHistUIForIPM[i]);
	}	
	
	SslOpen.Execute = true;
	brsstrcpy((UDINT) SslOpen.Name, (UDINT) "IPM_AlarmTLS");
	ArSslOpen(&SslOpen);
	sslIdent = SslOpen.Ident;
	
	Client.method 			= httpMETHOD_POST;
	Client.option 			= httpOPTION_HTTP_11;
	Client.sslCfgIdent		= sslIdent;
	Client.pHost 			= &clientSettings.host;
	Client.hostPort			= clientSettings.hostPort;
	Client.pUri 			= &clientSettings.resource;
	Client.pResponseData 	= &clientSettings.responseData;
	Client.responseDataSize = sizeof(clientSettings.responseData);
	Client.pRequestData		= &alarmSender.request;
	Client.pRequestHeader   = &clientSettings.requestHeader;
	
	alarmProcessingBlocked  = true;

}
