
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif

#define false 0
#define true 1

void ResetAlarmMesages (AlarmMessage* alarms);
STRING* GetAlarmState (MpAlarmXStateEnum enumState);
void GenerateAlarmJson(STRING* buffer, AlarmMessage *alarm);
void ClearAlarmHistory();

void _CYCLIC ProgramCyclic(void)
{
	if (alarmProcessingBlocked && GlobalAck)
	{
		alarmProcessingBlocked = false;
		ClearAlarmHistory();
	}
	if (alarmProcessingBlocked) return;
	
	//SMAZAT
	MpAlarmXBitSuperVisor(&gAlarm_EM01,setAlarm, "EM01_CM01_Kuka_Robot.Alarms.RobExt");
	MpAlarmXBitSuperVisor(&gAlarm_EM05,setAlarm, "EM05_CM01_Automaticky_rezim.Warnings.VychoziPoziceNedosazena");
	setAlarm = 0;
	
	switch (alarmReader.step)
	{
		case 0:
			alarmReader.delay.IN = false;
			if (brsstrcmp((UDINT) AlarmHistUIForIPMConn[0].AlarmList.Name[0], (UDINT) "") && alarmReader.dataProcessed) 
			{
				ResetAlarmMesages(alarmReader.alarmMessage);
				alarmReader.step = 1;
			}
			break;
		
		case 1:
			alarmReader.delay.IN = true;
			if (alarmReader.delay.Q)
			{
				alarmReader.delay.IN = false;
				alarmReader.step = 2;
			}
			break;
		
		case 2:
			for (int i = 0; i < MAX_ALARMS; i++)
			{
				if (!brsstrcmp((UDINT) AlarmHistUIForIPMConn[0].AlarmList.Message[i], (UDINT) "")) break;
				brsstrcpy((UDINT) alarmReader.alarmMessage[i].name,(UDINT) AlarmHistUIForIPMConn[0].AlarmList.Name[i]);
				alarmReader.alarmMessage[i].severity = AlarmHistUIForIPMConn[0].AlarmList.Severity[i];
				brsstrcpy((UDINT) alarmReader.alarmMessage[i].state, (UDINT) GetAlarmState(AlarmHistUIForIPMConn[0].AlarmList.NewState[i]));
				for (int j = 0; j < MAX_LANGUAGES; j++)
				{
					if (!brsstrcmp((UDINT) languages[j], (UDINT) "")) break;
					brsstrcpy((UDINT) alarmReader.alarmMessage[i].alarmText[j].language,(UDINT) AlarmHistUIForIPMConn[j].Language);
					brsmemcpy((UDINT) alarmReader.alarmMessage[i].alarmText[j].text,(UDINT) AlarmHistUIForIPMConn[j].AlarmList.Message[i], sizeof(AlarmHistUIForIPMConn[j].AlarmList.Message[i]));
				}
			}
			alarmReader.step = 3;
			break;
			
		case 3:
			ClearAlarmHistory();
			alarmReader.dataProcessed = false;
			alarmReader.step = 0;
			break;		
	}
	TON(&alarmReader.delay);
	for (int i = 0; i < MAX_LANGUAGES; i++) MpAlarmXHistoryUI(&AlarmHistUIForIPM[i]);
	
	switch (alarmSender.step)
	{
		case 0:
			alarmSender.currentAlarm = MAX_ALARMS;
			Client.enable = false;
			if ((alarmReader.step == 0) && !alarmReader.dataProcessed)
			{
				Client.enable = true;
				alarmSender.step = 1;
			}
			break;
		
		case 1:
			for (alarmSender.currentAlarm = MAX_ALARMS; alarmSender.currentAlarm >= 0; alarmSender.currentAlarm--)
			{
				if (brsstrcmp((UDINT) alarmReader.alarmMessage[alarmSender.currentAlarm].name, (UDINT) "")) break;
			}
			
			if (alarmSender.currentAlarm <= 0)
			{
				alarmReader.dataProcessed = true;
				alarmSender.step = 0;
			}else
			{
				alarmSender.step = 2;
			}
			break;
		
		case 2:
			GenerateAlarmJson(alarmSender.request, &alarmReader.alarmMessage[alarmSender.currentAlarm--]);
			Client.requestDataLen = brsstrlen((UDINT) alarmSender.request);
			clientSettings.requestHeader.contentLength = brsstrlen((UDINT) alarmSender.request);
			Client.send = true;
			alarmSender.step = 3;
			break;
		
		case 3:
			if (Client.httpStatus = 200)
			{
				Client.send = false;
				if (alarmSender.currentAlarm < 0)
				{
					alarmReader.dataProcessed = true;
					alarmSender.step = 0;
				}else
				{
					alarmSender.step = 2;
				}
			}
			break;
	}
	httpClient(&Client);
	
}

void ResetAlarmMesages (AlarmMessage* alarms)
{
	for (int i = 0; i < MAX_ALARMS; i++)
	{
		brsmemset((UDINT) alarms[i].name, 0, sizeof(alarms[i].name));
		alarms[i].severity = 0;
		brsmemset((UDINT) alarms[i].state, 0, sizeof(alarms[i].state));
		for (int j = 0; j < MAX_LANGUAGES; j++)
		{
			brsmemset((UDINT) alarms[i].alarmText[j].language, 0, sizeof(alarms[i].alarmText[j].language));	
			brsmemset((UDINT) alarms[i].alarmText[j].text, 0, sizeof(alarms[i].alarmText[j].text));
		}
	}
}

STRING* GetAlarmState (MpAlarmXStateEnum enumState)
{
	static STRING actState[20];
	switch (enumState)
	{
		case  mpALARMX_STATE_NONE:
			brsstrcpy((UDINT) actState, (UDINT) "NONE");
			break;
		
		case  mpALARMX_STATE_ACTIVE:
			brsstrcpy((UDINT) actState, (UDINT)"ACTIVE");
			break;
		
		case mpALARMX_STATE_INACTIVE:
			brsstrcpy((UDINT) actState, (UDINT)"INACTIVE");
			break;
			
		case mpALARMX_STATE_ACKNOWLEDGED:
			brsstrcpy((UDINT) actState, (UDINT)"ACKNOWLEDGED");
			break;
			
		case mpALARMX_STATE_UNACKNOWLEDGED:
			brsstrcpy((UDINT) actState, (UDINT)"UNACKNOWLEDGED");
			break;
		
		default:
			brsstrcpy((UDINT) actState, (UDINT)"UNKNOWN");
			break;	
	}
	return actState;
}

void GenerateAlarmJson(STRING* buffer, AlarmMessage *alarm) 
{
	brsstrcpy((UDINT) buffer, (UDINT) "{\"alarmMessage\":{\"Name\":\"");
	brsstrcat((UDINT) buffer, (UDINT) alarm->name);
	brsstrcat((UDINT) buffer, (UDINT) "\",\"Severity\":");
	brsitoa(alarm->severity, (UDINT) (buffer + brsstrlen((UDINT) buffer)));
	brsstrcat((UDINT) buffer, (UDINT) ",\"State\":\"");
	brsstrcat((UDINT) buffer, (UDINT) alarm->state);
	brsstrcat((UDINT) buffer, (UDINT) "\",\"AlarmTexts\":[");

	for (UINT i = 0; i < MAX_LANGUAGES; i++) 
	{
		if (brsstrlen((UDINT) alarm->alarmText[i].language) == 0) break; 

		brsstrcat((UDINT) buffer, (UDINT) "{\"Language\":\"");
		brsstrcat((UDINT) buffer, (UDINT) alarm->alarmText[i].language);
		brsstrcat((UDINT) buffer, (UDINT) "\",\"Text\":\"");
		
		STRING tempText[250]; 
		WStringToUTF8.enable = true;
		WStringToUTF8.pDest = (UDINT) tempText;
		WStringToUTF8.pSrc = (UDINT) alarm->alarmText[i].text;
		WStringToUTF8.destSize = sizeof(tempText);
		httpWStringToUtf8(&WStringToUTF8);
		
		brsstrcat((UDINT) buffer, (UDINT) tempText);
		brsstrcat((UDINT) buffer, (UDINT) "\"}");

		if (i < MAX_LANGUAGES - 1 && brsstrlen((UDINT) alarm->alarmText[i + 1].language) > 0) brsstrcat((UDINT) buffer, (UDINT) ",");
	}

	brsstrcat((UDINT) buffer, (UDINT) "]}}");
}

void ClearAlarmHistory()
{
	for (int i = 0; i < MAX_LANGUAGES; i++)
	{
		MpAlarmXClearHistory((MpComIdentType*) &alarmHistMpLinks[i]);
	}
}