
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

#define false 0
#define true 1

void _EXIT ProgramExit(void)
{
	Client.enable = false;
	Client.send = false;
	httpClient(&Client);
	
	for (int i = 0; i < MAX_LANGUAGES; i++)
	{	
		AlarmHistUIForIPM[i].Enable = false;
		MpAlarmXHistoryUI(&AlarmHistUIForIPM[i]);
	}
}
