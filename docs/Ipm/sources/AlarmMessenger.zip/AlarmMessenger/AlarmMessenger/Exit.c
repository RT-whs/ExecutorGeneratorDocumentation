
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

#define false 0
#define true 1

void _EXIT ProgramExit(void)
{
	Client.enable = false;
	Client.send = false;
	httpsClient(&Client);
	
	for (int i = 0; i < MAX_LANGUAGES; i++)
	{	
		AlarmHistForIPM[i].Enable = false;
		AlarmHistUIForIPM[i].Enable = false;
		MpAlarmXHistory(&AlarmHistForIPM[i]);
		MpAlarmXHistoryUI(&AlarmHistUIForIPM[i]);
	}
}
